from django.urls import path
from django.conf.urls import include, url
from . import views

urlpatterns = [
  # path('', views.index, name='index'),
  path('revenue_management', views.revenue, name='revenue'),
  path('pricings_strategies', views.pricing, name='pricing'),
  path('inventory_optimization', views.inventory, name='inventory'),
  path('yield_management', views.yieldm, name='yieldm'),
  url(r'^upload_csv/(?P<model_name>\w+)/$', views.upload_csv, name='upload_csv'),
  url(r'^display_data/(?P<model_name>\w+)/$', views.display_data, name='display_data'),
  # path('display_data', views.display_data, name='display_data'),

]