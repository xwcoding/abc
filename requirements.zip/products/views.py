from django.shortcuts import render, HttpResponse
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
import logging, datetime

logger = logging.getLogger(__name__)

def revenue(request):
  return render(request, 'products/revenue.html')

def pricing(request):
  return render(request, 'products/pricing.html')

def inventory(request):
  return render(request, 'products/inventory.html')

def yieldm(request):
  return render(request, 'products/yieldm.html')

def upload_csv(request, model_name):  # pass model name to upload_csv, then save in session
  # call api model to process data
  print('get model_name: ', model_name)
  context = {'model_name': model_name}

  if request.method == 'GET':
    return render(request, 'products/upload_csv.html', context)
  else:

    # print('request.post: ', request.POST)
    
    csv_file = request.FILES['csv_file']
    # print('size: ', csv_file.size)
    if not csv_file.name.endswith('.csv'):
      messages.warning(request, 'WARNING: File is not in csv format')
      warning_msg = 'User: {user}, Message: File is not in csv format'.format(user=request.user)
      logger.warning(warning_msg)
      return render(request, 'products/upload_csv.html', context)
    else:
      if csv_file.multiple_chunks():   # check if file size > 2.5MB
        messages.warning(request, 'Please limit your file size within 2.5MB')
        warning_msg = 'User: {user}, Message: File size more than 2.5MB'.format(user=request.user)
        logger.warning(warning_msg)
        return render(request, 'products/upload_csv.html', context)
      else:
        try:
          file_data = csv_file.read().decode("utf-8")
          fs=FileSystemStorage()                  # this will save to myapp\uploaded\files, default to MEDIA_ROOT = 'uploaded_files/'
          fs.save(csv_file.name, csv_file)

          request.session['data_'+model_name] = file_data
          request.session[model_name] = model_name  # add model name to session
        except Exception as e:
          error_msg = 'User: {user}, Error: Check charset or file system'.format(user=request.user)
          logger.error(error_msg, repr(e))
    return HttpResponseRedirect(reverse('api:process_'+model_name))

def display_data(request, model_name):      # show model name in UI
  # if request.method == 'GET':
  print(request)
  data = request.session.get('data_'+model_name)  #get data from upload_csv view by using session
  context = {'model_name': model_name,'data': data}
  return render(request, 'products/display_data.html', context)


