from django.shortcuts import render, HttpResponseRedirect, HttpResponse
from django.urls import reverse
from .forms import ContactForm
from .models import Contact

def index(request):
  return render(request, 'general/index.html')

def about(request):
  print(request)
  return render(request, 'general/about.html')

def goals(request):
  return render(request, 'general/goals.html')

def contact(request):
  """ contact form """
  if request.method != 'POST':
    form = ContactForm()
    print(form)
  else:
    form = ContactForm(request.POST)
    if form.is_valid():
      # form.save(commit=False)
      form.save()
      return HttpResponse('general/submitted.html')
  return render(request, 'general/contact.html', {'form':form})

  


