from django import forms
from .models import Contact

class ContactForm(forms.ModelForm):
  class Meta:
    model = Contact
    fields = ['title', 'first_name', 'last_name', 'company', 'address', 'email', 'phone', 'message']
    labels = {'first_name':'First Name', 'last_name':'Last Name'}
    widgets = {'message': forms.Textarea(attrs={'cols':50})}
