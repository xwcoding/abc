from django.db import models
from django.contrib.auth.models import User


class Contact(models.Model):
  title = models.CharField(max_length = 200)
  first_name = models.CharField(max_length = 50)
  last_name = models.CharField(max_length = 50)
  company = models.CharField(max_length = 50)
  address = models.CharField(max_length = 100, null=True, blank=True)
  email = models.EmailField()
  phone = models.CharField(max_length = 15, null=True, blank=True)
  message = models.TextField()
  submit_date = models.DateTimeField(auto_now_add=True)

  def __str__(self):
    return self.title

