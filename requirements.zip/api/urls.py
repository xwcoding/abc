from django.urls import path
from django.conf.urls import include, url
from . import views

urlpatterns = [
  # path('', views.index, name='index'),
  path('process_model_1', views.process_model_1, name='process_model_1'),
  path('process_model_2', views.process_model_2, name='process_model_2'),
]