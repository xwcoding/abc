from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect
import logging
logger = logging.getLogger(__name__)
def process_data(data):
  processed_data = []
  if type(data) == str:           # check if data is a string
    lines = data.split('\r\n')    # create lines for data rows in csv
    if isinstance(lines, list):   # check if lines are a list
      if not lines[len(lines)-1]:
        lines.pop(len(lines)-1)       # remove the last line if it is empty
      headers = lines[0].split(',') # get header list from 1st row
      lines.pop(0)                  # remove the header row from lines before processing data
      for line in lines:
        fields = line.split(',')    # create a list for each row i.e. 1, 2, 3
        data_dict = {}
        for header in headers:
          data_dict[header] = fields[headers.index(header)] # assgin value to each data_dict
        processed_data.append(data_dict)                    # append data to process_data list
    else:
      logger.error('Data string cannot be converted to a list')
  else:
    error_msg = 'Message: Data is not a valid string'
    logger.error(error_msg)
  return processed_data

def process_model_1(request):
  file_data = request.session.get('data_model_1')
  data = process_data(file_data)
  
  request.session['data_model_1'] = data
  # print('model_name: ', request.session.get('model_1'))
  # print('model 1 data: ', data)
  return HttpResponseRedirect(reverse('products:display_data', kwargs={'model_name': 'model_1'}))

def process_model_2(request):
  file_data = request.session.get('data_model_2')
  data = process_data(file_data)
  
  request.session['data_model_2'] = data
  # print('model_name: ', request.session.get('model_1'))
  # print('model 1 data: ', data)
  return HttpResponseRedirect(reverse('products:display_data', kwargs={'model_name': 'model_2'}))
