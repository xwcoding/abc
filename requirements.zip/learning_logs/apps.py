from django.apps import AppConfig


class LeanrningLogsConfig(AppConfig):
    name = 'leanrning_logs'
